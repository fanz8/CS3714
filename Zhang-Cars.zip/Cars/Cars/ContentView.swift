
//
//  ContentView.swift
//  Cars
//
//  Created by Osman Balci on 2/2/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import WebKit
 
struct ContentView : View {
  
    @State private var selectedCar = listOfCars[0]
  
    var body: some View {
        ZStack {
            // Color the background to light gray
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
        VStack {
            Text("Automobiles")
                .font(.headline)
            Divider()
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(listOfCars, id: \.id) { aCar in
                  
                        Button(action: {
                            self.selectedCar = aCar
                        }) {
                            VStack {
                                Image(aCar.logoFileName)
                                    .renderingMode(.original)
                                Text(aCar.manufacturer.replacingOccurrences(of: " ", with: "\n"))
                                    .fixedSize()
                                    .foregroundColor(aCar.manufacturer == self.selectedCar.manufacturer ? .red : .blue)
                                    .multilineTextAlignment(.center)
                            }
                        }   // End of Button
                      
                    }   // End of ForEach
                  
                }   // End of HStack
                // Set font and size for the whole HStack content
                .font(.system(size: 14))
              
            }   // End of ScrollView
            // ScrollView must know its width to be able to scroll horizontally
            .frame(width: UIScreen.main.bounds.width - 20)
            // Fixes ScrollView at its ideal size. Button names do not truncate.
            .fixedSize()
           
            Divider()
            WebView(showURL: self.selectedCar.website)
                .frame(width: UIScreen.main.bounds.width)
          
        }   // End of VStack
        }   // End of ZStack
    }
}
 
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
 
 
 
