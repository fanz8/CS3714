//
//  Car.swift
//  Cars
//
//  Created by ZhangFan on 2/3/20.
//  Copyright © 2020 Fan Zhang. All rights reserved.
//

import Foundation
import SwiftUI

struct Car: Hashable, Codable,Identifiable {
    var id: Int
    var manufacturer:String
    var logoFileName:String
    var website:String
}

/*
{
    "id": 1,
    "manufacturer": "BMW",
    "logoFileName": "bmw",
    "website": "https://www.bmwusa.com/"
}
*/
