//
//  CarData.swift
//  Cars
//
//  Created by Osman Balci on 2/2/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import Foundation
 
// Global array of Car structs
var listOfCars = [Car]()
 
/*
 **************************
 MARK: - Read Car Data File
 **************************
 */
public func readCarDataFile() {
 
    listOfCars = loadFromMainBundle("CarData.json")
}
 
/*
*******************************************
MARK: - Load Car Data File from Main Bundle
*******************************************
*/
func loadFromMainBundle<T: Decodable>(_ filename: String, as type: T.Type = T.self) -> T {
    let data: Data
  
    guard let file = Bundle.main.url(forResource: filename, withExtension: nil)
        else {
            fatalError("Unable to find \(filename) in main bundle.")
    }
    
    do {
        data = try Data(contentsOf: file)
    } catch {
        fatalError("Unable to load \(filename) from main bundle:\n\(error)")
    }
  
    do {
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Unable to parse \(filename) as \(T.self):\n\(error)")
    }
}


 
 
