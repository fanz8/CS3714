//
//  ContentView.swift
//  Calculator
//
//  Created by ZhangFan on 1/29/20.
//  Copyright © 2020 Fan Zhang. All rights reserved.
//

import SwiftUI

fileprivate var errorOccurred = false
fileprivate var leftSideValue = 0.0
fileprivate var rightSideValue = 0.0


struct ContentView: View {
    
    @State private var result = ""
    
    var body: some View {
        ZStack{
        Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            VStack(spacing:40){
                Text(result)
                    .frame(width: UIScreen.main.bounds.width - 30,height: 40,alignment: .center).background(RoundedRectangle(cornerRadius: 16).strokeBorder(Color.red, lineWidth: 2)).truncationMode(.head)
                //Text("")
                //let result = ""
                HStack(spacing: 130){
                    Button(action: {
                        self.buttonTapped(buttonTag:10)
                    }){
                        Text("Clear")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:11)
                    }){
                        Image(systemName:"divide")
                        .foregroundColor(.black)
                    }
                }//End of HStack
                HStack(spacing: 30){
                    Button(action: {
                        self.buttonTapped(buttonTag:7)
                    }){
                        Image(systemName:"7.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:8)
                    }){
                        Image(systemName:"8.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:9)
                    }){
                        Image(systemName:"9.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:12)
                    }){
                        Image(systemName:"multiply")
                        .foregroundColor(.black)
                    }
                }//End of HStack
                HStack(spacing: 30){
                    Button(action: {
                        self.buttonTapped(buttonTag:4)
                    }){
                        Image(systemName:"4.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:5)
                    }){
                        Image(systemName:"5.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:6)
                    }){
                        Image(systemName:"6.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:13)
                    }){
                        Image(systemName:"minus")
                            .foregroundColor(.black)
                    }
                }//End of HStack
                HStack(spacing: 30){
                    Button(action: {
                        self.buttonTapped(buttonTag:1)
                    }){
                        Image(systemName:"1.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:2)
                    }){
                        Image(systemName:"2.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:3)
                    }){
                        Image(systemName:"3.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:14)
                    }){
                        Image(systemName:"plus")
                            .foregroundColor(.black)
                    }
                }//End of HStack
                HStack(spacing: 64){
                    Button(action: {
                        self.buttonTapped(buttonTag:0)
                    }){
                        Image(systemName:"0.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:15)
                    }){
                        Image(systemName:"dot.square")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag:16)
                    }){
                        Image(systemName:"equal")
                            .foregroundColor(.black)
                    }
                }//End of HStack
            }//End of VStack
                .imageScale(.large)
                .font(Font.title.weight(.regular))
        }//End of ZStack
    }
    
    func buttonTapped(buttonTag: Int){
        switch buttonTag {
        case 0...9:
            result += String(buttonTag)
            
        case 10:
            errorOccurred = false
            leftSideValue = 0.0
            rightSideValue = 0.0
            result = ""
            
        case 11:
            if result.isEmpty{ return }
            
            result += " ÷ "
        case 12:
            if result.isEmpty{ return }
            
            result += " × "
        case 13:
            if result.isEmpty{ return }
            
            result += " - "
        case 14:
            if result.isEmpty{ return }
            
            result += " + "
        case 15:
            if result.isEmpty{ return }
            
            result += "."
        case 16:
            if result.isEmpty{ return }
            
            result += " = "
            
            for char in result {
                if char == "÷"{
                    computeResult(forOperator: "÷")
                }else if char == "×"{
                    computeResult(forOperator: "×")
                }else if char == "-"{
                    computeResult(forOperator: "-")
                }else if char == "+"{
                    computeResult(forOperator: "+")
                }
            }
        default:
            print ("Button tag number is out of range!")
        }
    }
    func computeResult(forOperator: String){
        if errorOccurred{ return }
        
        var computeResult = 0.0
        
        let resultWithoutEqualSign = result.replacingOccurrences(of: "=", with: "")
        let parts = resultWithoutEqualSign.components(separatedBy: forOperator)
        
        if parts.count > 2{
            result += "Error"
            errorOccurred = true
            return
        }
        
        let part0 = parts[0].trimmingCharacters(in: .whitespacesAndNewlines)
        let part1 = parts[1].trimmingCharacters(in: .whitespacesAndNewlines)
        
        let part0Entered:Double? = Double(part0)
        let part1Entered:Double? = Double(part1)
        
        if let part0Value = part0Entered{
            leftSideValue = part0Value
            
            if let part1Value = part1Entered{
                rightSideValue = part1Value
            }else{
                result += "Error"
                errorOccurred = true
                return
            }
        }else{
            result += "Error"
            errorOccurred = true
            return
        }
        switch forOperator{
            case "÷":
                computeResult = leftSideValue / rightSideValue
            case "×":
                computeResult = leftSideValue * rightSideValue
            case "-":
                computeResult = leftSideValue - rightSideValue
            case "+":
                computeResult = leftSideValue + rightSideValue
        default:
            print("Invalid arithmetic operator symbol")
        }
        result += String(format: "%.3f",computeResult)
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
