//
//  VoiceMemoItem.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct VoiceMemoItem: View {
    // Input Parameter
    let voiceMemo: VoiceMemo
   
    var body: some View {
        HStack {
            Image("VoiceMemo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 60.0, height: 60.0)
          
            VStack(alignment: .leading) {
                Text(verbatim: voiceMemo.title)
                    .foregroundColor(.blue)
                HStack {
                    Text("Created: ")
                    Text(verbatim: voiceMemo.dateTime)
                }
                HStack {
                    Text("Duration: ")
                    Text(verbatim: voiceMemo.duration)
                }
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
          
        }   // End of HStack
    }
}
 
struct VoiceMemoItem_Previews: PreviewProvider {
    static var previews: some View {
        VoiceMemoItem(voiceMemo: voiceMemoStructList[0])
    }
}
 
 
