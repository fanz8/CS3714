//
//  VoiceMemoDetails.swift
//  Communicate
//
//  Created by Osman Balci on 3/10/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import AVFoundation
 
struct VoiceMemoDetails: View {
    // Input Parameter
    let voiceMemo: VoiceMemo
   
    @EnvironmentObject var userData: UserData
    @EnvironmentObject var audioPlayer: AudioPlayer
   
    // Enable this View to be dismissed to go back when the Save button is tapped
    @Environment(\.presentationMode) var presentationMode
   
    @State private var newVoiceMemoTitle = ""
    @State private var changeVoiceMemoTitle = false
   
    var body: some View {
        Form {
            Section(header: Text("Voice Memo Title")) {
                voiceMemoTitleSubview
            }
            Section(header: Text("Voice Memo Date and Time")) {
                Text(verbatim: voiceMemo.dateTime)
            }
            Section(header: Text("Voice Memo Duration Time")) {
                Text(verbatim: voiceMemo.duration)
            }
            Section(header: Text("Play Voice Memo")) {
                Button(action: {
                    if self.audioPlayer.isPlaying {
                        self.audioPlayer.pauseAudioPlayer()
                    } else {
                        self.audioPlayer.startAudioPlayer()
                    }
                }) {
                    Image(systemName: self.audioPlayer.isPlaying ? "pause.fill" : "play.fill")
                        .foregroundColor(.blue)
                        .font(Font.title.weight(.regular))
                    }
            }
 
        }   // End of Form
        // Set font and size for the whole Form content
        .font(.system(size: 14))
        .navigationBarTitle(Text("Voice Memo Details"), displayMode: .inline)
        .navigationBarItems(trailing:
            Button(action: {
                if !self.newVoiceMemoTitle.isEmpty {
                    self.changeTitle()
                }
            }) {
                Text("Save")
            })
        .onAppear() {
            self.createPlayer()
        }
        .onDisappear() {
            self.audioPlayer.stopAudioPlayer()
        }
    }   // End of body
   
    var voiceMemoTitleSubview: some View {
        return AnyView(
            VStack {
                HStack {
                    Text(verbatim: voiceMemo.title)
                    Button(action: {
                        self.changeVoiceMemoTitle.toggle()
                    }) {
                        Image(systemName: "pencil.circle")
                            .imageScale(.large)
                            .foregroundColor(.blue)
                    }
                }
                if self.changeVoiceMemoTitle {
                    TextField("Change Voice Memo Title", text: $newVoiceMemoTitle)
                         .textFieldStyle(RoundedBorderTextFieldStyle())
                }
            }
        )
    }
   
    /*
    --------------------------------------------
    MARK: - Create Voice Memo with Changed Title
    --------------------------------------------
    */
    func changeTitle() {
       
        // Capitalize the entered new voice memo title
        let capitalizedNewTitle = self.newVoiceMemoTitle.capitalized
       
        //----------------------
        // Create New Voice Memo
        //----------------------
       
        // We must use the same id since it is the recording filename
        let newVoiceMemo = VoiceMemo(id: voiceMemo.id,
                                  title: capitalizedNewTitle,
                                  dateTime: voiceMemo.dateTime,
                                  duration: voiceMemo.duration)
 
        //----------------------
        // Delete Old Voice Memo
        //----------------------
       
        // Obtain the index number of the old Voice Memo struct
        let indexNumber = userData.voiceMemosList.firstIndex(where: { $0.id == voiceMemo.id })
       
        // Delete the old Voice Memo struct
        userData.voiceMemosList.remove(at: indexNumber!)
       
        //----------------------
        // Append New Voice Memo
        //----------------------
       
        // Append the new voice memo to the list
        userData.voiceMemosList.append(newVoiceMemo)
 
        // Set the global variable point to the changed list
        voiceMemoStructList = userData.voiceMemosList
       
        // Dismiss this View and go back
        self.presentationMode.wrappedValue.dismiss()
    }
   
    /*
    ---------------------------
    MARK: - Create Audio Player
    ---------------------------
    */
    func createPlayer() {
       
        let filename = voiceMemo.id.uuidString + ".m4a"
        let voiceMemoFileUrl = documentDirectory.appendingPathComponent(filename)
       
        audioPlayer.createAudioPlayer(url: voiceMemoFileUrl)
    }
}
 
struct VoiceMemoDetails_Previews: PreviewProvider {
    static var previews: some View {
        VoiceMemoDetails(voiceMemo: voiceMemoStructList[0])
    }
}
 
 
