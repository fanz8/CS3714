//
//  VoiceMemos.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct VoiceMemos: View {
      
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
  
    var body: some View {
        NavigationView {
            List {
                ForEach(userData.voiceMemosList) { aVoiceMemo in
                    NavigationLink(destination: VoiceMemoDetails(voiceMemo: aVoiceMemo)) {
                        VoiceMemoItem(voiceMemo: aVoiceMemo)
                    }
                }
                .onDelete(perform: delete)
                .onMove(perform: move)
              
            }   // End of List
            .navigationBarTitle(Text("My Voice Memos"), displayMode: .inline)
          
            // Place the Edit button on left and Add (+) button on right of the navigation bar
            .navigationBarItems(leading: EditButton(), trailing:
                NavigationLink(destination: RecordVoiceMemo()) {
                    Image(systemName: "plus")
                })
          
        }   // End of NavigationView
    }
  
    /*
     ----------------------------------
     MARK: - Delete Selected Voice Memo
     ----------------------------------
     */
    func delete(at offsets: IndexSet) {
        if let first = offsets.first {
       
            let idOfFileToDelete = userData.voiceMemosList[first].id
            let nameOfFileToDelete = idOfFileToDelete.uuidString + ".m4a"
            let urlOfFileToDelete = documentDirectory.appendingPathComponent(nameOfFileToDelete)
           
            do {
                let fileManager = FileManager.default
               
                // Delete the selected voice memo audio file from the document directory
                try fileManager.removeItem(at: urlOfFileToDelete)
               
                // Remove the selected voice memo from the list
                userData.voiceMemosList.remove(at: first)
               
                // Set the global variable point to the changed list
                voiceMemoStructList = userData.voiceMemosList
            } catch {
               print("Unable to delete audio file in document directory!")
            }
        } else {
            print("Unable to delete selected voice memo!")
        }
    }
  
    /*
     --------------------------------
     MARK: - Move Selected Voice Memo
     --------------------------------
     */
    func move(from source: IndexSet, to destination: Int) {
 
        userData.voiceMemosList.move(fromOffsets: source, toOffset: destination)
      
        // Set the global variable point to the changed list
        voiceMemoStructList = userData.voiceMemosList
    }
}
 
struct VoiceMemos_Previews: PreviewProvider {
    static var previews: some View {
        VoiceMemos()
            .environmentObject(UserData())
    }
}
 
 
