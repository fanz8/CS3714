//
//  RecordVoiceMemo.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import AVFoundation
 
fileprivate var idAndFilename = UUID()
 
struct RecordVoiceMemo: View {
   
    @EnvironmentObject var userData: UserData
   
    // Enable this View to be dismissed to go back when the Save button is tapped
    @Environment(\.presentationMode) var presentationMode
   
    @State private var recordingVoice = false
    @State private var voiceMemoTitle = ""
    @State private var showErrorAlert = false
    @State private var showSavedAlert = false
   
    var body: some View {
        Form {
            Section(header: Text("Voice Memo Title")) {
                TextField("Enter voice memo title", text: $voiceMemoTitle)
                    .disableAutocorrection(true)
                    .autocapitalization(.words)
            }
            Section(header: Text("Voice Memo Duration Time")) {
                Text(userData.voiceRecordingDuration)
            }
            Section(header: Text("Voice Recording")) {
                Button(action: {
                    self.microphoneTapped()
                }) {
                    microphoneLabel
                }
                .alert(isPresented: $showSavedAlert, content: { self.savedAlert })
                /*
                 ----------------------------------------------------------------------------
                 Modifying the same view with more than one .alert does not work!
                 You should modify a different view for each .alert to work. Therefore,
                 savedAlert is attached to the Button and errorAlert is attached to the Form.
                 ----------------------------------------------------------------------------
                 */
            }
 
        }   // End of Form
        // Set font and size for the whole Form content
        .font(.system(size: 14))
        .navigationBarTitle(Text("Record New Voice Memo"), displayMode: .inline)
        .alert(isPresented: $showErrorAlert, content: { self.errorAlert })
        .navigationBarItems(trailing:
           Button(action: {
               self.saveNewVoiceMemo()
           }) {
               Text("Save")
           })
 
    }   // End of body
   
    /*
    ------------------------
    MARK: - Supporting Views
    ------------------------
    */
   
    var microphoneLabel: some View {
        VStack {
            Image(systemName: recordingVoice ? "mic.fill" : "mic.slash.fill")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.blue)
                .padding()
            Text(recordingVoice ? "Recording your voice... Tap to Stop!" : "Start Recording!")
                .multilineTextAlignment(.center)
        }
    }
   
    var errorAlert: Alert {
        Alert(title: Text("Missing Title and/or Recording!"),
            message: Text("Please enter a title and record your new voice memo!"),
            dismissButton: .default(Text("OK")))
    }
   
    var savedAlert: Alert {
       Alert(title: Text("Recording Saved!"),
           message: Text("Your Voice Memo is successfully saved!"),
           dismissButton: .default(Text("OK")))
    }
   
    /*
    -------------------------
    MARK: - Microphone Tapped
    -------------------------
    */
    func microphoneTapped() {
        if audioRecorder == nil {
            self.recordingVoice = true
            userData.startDurationTimer()
            startRecording()
        } else {
            self.recordingVoice = false
            userData.stopDurationTimer()
            finishRecording()
        }
    }
   
    /*
    ----------------------------------
    MARK: - Start Voice Memo Recording
    ----------------------------------
    */
    func startRecording() {
       
        idAndFilename = UUID()
        let filename = idAndFilename.uuidString + ".m4a"
        let audioFilenameUrl = documentDirectory.appendingPathComponent(filename)
   
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
   
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilenameUrl, settings: settings)
            audioRecorder.record()
        } catch {
            finishRecording()
        }
    }
 
    /*
    -----------------------------------
    MARK: - Finish Voice Memo Recording
    -----------------------------------
    */
    func finishRecording() {
        audioRecorder.stop()
        audioRecorder = nil
        self.recordingVoice = false
    }
 
    /*
    ---------------------------
    MARK: - Save New Voice Memo
    ---------------------------
    */
    func saveNewVoiceMemo() {
     
        // Input Data Validation
        if self.voiceMemoTitle.isEmpty || userData.voiceRecordingDuration.isEmpty {
           self.showErrorAlert = true
           return
        } else {
           self.showErrorAlert = false
        }
       
        // Instantiate a Date object
        let date = Date()
        
        // Instantiate a DateFormatter object
        let dateFormatter = DateFormatter()
        
        // Set the date format to yyyy-MM-dd at HH:mm:ss
        dateFormatter.dateFormat = "yyyy-MM-dd' at 'HH:mm:ss"
        
        // Format the Date object as above and convert it to String
        let currentDateTime = dateFormatter.string(from: date)
       
        // Capitalize the entered voice memo title
        let capitalizedTitle = self.voiceMemoTitle.capitalized
 
        // Create a new instance of VoiceMemo struct and dress it up
        let newVoiceMemo = VoiceMemo(id: idAndFilename,
                                     title: capitalizedTitle,
                                     dateTime: currentDateTime,
                                     duration: userData.voiceRecordingDuration)
       
        // Append the new voice memo to the list
        userData.voiceMemosList.append(newVoiceMemo)
       
        // Initialize voiceRecordingDuration
        userData.voiceRecordingDuration = ""
      
        // Set the global variable point to the changed list
        voiceMemoStructList = userData.voiceMemosList
       
        self.showSavedAlert = true
     
       // Dismiss this View and go back
       self.presentationMode.wrappedValue.dismiss()
    }
   
}
 
struct RecordVoiceMemo_Previews: PreviewProvider {
    static var previews: some View {
        RecordVoiceMemo()
    }
}
 
 
 
