//
//  SpeechToText.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import Speech
import AVFoundation
 
struct SpeechToText: View {
   
    @State private var recordingVoice = false
    @State private var speechConvertedToText = ""
   
    var body: some View {
        VStack {
            Button(action: {
                self.microphoneTapped()
            }) {
                microphoneLabel
            }
            .padding()
            Text(speechConvertedToText)
                .multilineTextAlignment(.center)
                // This enables the text to wrap around on multiple lines
                .fixedSize(horizontal: false, vertical: true)
        }
        .onDisappear() {
            self.speechConvertedToText = ""
        }
    }
   
    /*
    -----------------------
    MARK: - Supporting View
    -----------------------
    */
    var microphoneLabel: some View {
        VStack {
            Image(systemName: recordingVoice ? "mic.fill" : "mic.slash.fill")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.blue)
            Text(recordingVoice ? "Recording your voice... Tap to Stop!" : "Convert Speech to Text!")
                .padding()
                .multilineTextAlignment(.center)
        }
    }
   
    /*
    -------------------------
    MARK: - Microphone Tapped
    -------------------------
    */
    func microphoneTapped() {
        if recordingVoice {
            cancelRecording()
            self.recordingVoice = false
        } else {
            self.recordingVoice = true
            recordAndRecognizeSpeech()
        }
    }
 
    /*
    ------------------------
    MARK: - Cancel Recording
    ------------------------
    */
    func cancelRecording() {
        request.endAudio()
        audioEngine.inputNode.removeTap(onBus: 0)
        audioEngine.stop()
        recognitionTask?.finish()
    }
 
    /*
    ----------------------------------------------
    MARK: - Record Audio and Transcribe it to Text
    ----------------------------------------------
    */
    func recordAndRecognizeSpeech() {
        //--------------------
        // Set up Audio Buffer
        //--------------------
        let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            request.append(buffer)
        }
       
        //---------------------
        // Prepare Audio Engine
        //---------------------
        audioEngine.prepare()
       
        //-------------------
        // Start Audio Engine
        //-------------------
        do {
            try audioEngine.start()
        } catch {
            print("Unable to start Audio Engine!")
            return
        }
       
        //-------------------------------
        // Convert recorded voice to text
        //-------------------------------
        recognitionTask = speechRecognizer.recognitionTask(with: request, resultHandler: { result, error in
           
            if result != nil {  // check to see if result is empty (i.e. no speech found)
                if let resultObtained = result {
                    let bestString = resultObtained.bestTranscription.formattedString
                    self.speechConvertedToText = bestString
                    
                } else if let error = error {
                    print("Transcription failed, but will continue listening and try to transcribe. See \(error)")
                }
            }
        })
    }
 
}
 
struct SpeechToText_Previews: PreviewProvider {
    static var previews: some View {
        SpeechToText()
    }
}
 
 
