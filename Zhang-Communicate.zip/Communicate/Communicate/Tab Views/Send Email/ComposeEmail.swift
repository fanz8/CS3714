//
//  ComposeEmail.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import MessageUI
 
struct ComposeEmail: View {
   
    @Binding var isShowing: Bool
   
    var body: some View {
        // Email struct UIViewControllerRepresentable is given in EmailData.swift
        Email(isShowing: $isShowing)
    }
}
 
 
