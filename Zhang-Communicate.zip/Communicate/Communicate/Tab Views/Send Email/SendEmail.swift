//
//  SendEmail.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import MessageUI
 
struct SendEmail: View {
 
    @State var showEmailView = false
 
    var body: some View {
        ZStack {
            VStack {
                Button(action: {
                    self.showEmailView.toggle()
                }) {
                    Text("Show Email Composition View")
                }
            }
            /*
             emailView() is triggered on the background (ZStack) and
             presented in the foreground covering over the button.
             */
            if showEmailView {
                emailView()
                    // Animate moving the email view from bottom up
                    .transition(.move(edge: .bottom))
                    .animation(.default)
               
            }   // End of VStack
        }   // End of ZStack
    }
 
    private func emailView() -> some View {
        if MFMailComposeViewController.canSendMail() {
            // Mail app is set up on user's device to send email
            return AnyView(ComposeEmail(isShowing: $showEmailView))
           
        } else {
            // Mail app is not set up on user's device to send email
            return AnyView(
                VStack {
                    Image(systemName: "exclamationmark.triangle")
                        .imageScale(.large)
                        .font(Font.title.weight(.medium))
                        .foregroundColor(.red)
                        .padding()
                    Text("Mail App is Not Set Up!\nPlease set up your Mail app on your iOS device to be able to send email!")
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 200)
            )
        }
    }
}
 
 
struct SendEmail_Previews: PreviewProvider {
    static var previews: some View {
        SendEmail()
    }
}
 
 
