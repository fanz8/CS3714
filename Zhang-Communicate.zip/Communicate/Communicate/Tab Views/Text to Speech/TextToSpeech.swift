//
//  TextToSpeech.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
import AVFoundation
 
struct TextToSpeech: View {
   
    @State private var textFieldValue = ""
    @State private var textEntered = ""
   
    var body: some View {
        NavigationView {
            Form {
                Section(header:
                    Text("Enter Text to Convert to Speech")
                        .padding(.top, 100)   // Put padding here to preserve form's background color
                ) {
                    HStack {
                        TextField("Enter Text to Convert to Speech", text: $textFieldValue,
                            onCommit: {
                                // Record entered value after Return key is pressed
                                self.textEntered = self.textFieldValue
                            }
                        )
                        // Button to clear the stock symbol text field
                        Button(action: {
                            self.textFieldValue = ""
                            self.textEntered = ""
                        }) {
                            Image(systemName: "multiply.circle")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }
                // Show this section only after Return key is pressed
                if !textEntered.isEmpty {
                    Section(header: Text("Convert Entered Text to Speech")) {
                        HStack {
                            Button(action: {
                                self.convertTextToSpeech()
                            }) {
                                Image(systemName: "speaker.3.fill")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                            }
                            Text("Speak")
                        }
                    }
                }
            }   // End of Form
            .navigationBarTitle(Text("Text to Speech Conversion"), displayMode: .inline)
          
        }   // End of NavigationView
    }
  
    /*
    ------------------------------
    MARK: - Convert Text to Speech
    ------------------------------
    */
    func convertTextToSpeech() {
      
        // Create an AVSpeechUtterance instance with the text to be spoken
        let speechUtterance = AVSpeechUtterance(string: textEntered)
       
        /*
         Set the speech language to English with U.S. dialect.
         Some of the English language dialects:
           English (Australia):         en-AU
           English (Ireland):           en-IE
           English (South Africa):      en-ZA
           English (United Kingdom):    en-GB
           English (United States):     en-US
         */
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        /*
         Set the speed (rate) at which entered text will be spoken;
         The higher the rate, the faster the speech will be.
         */
        speechUtterance.rate = 0.5
       
        /*
         Instantiate an object from the AVSpeechSynthesizer class and
         store its object reference into local variable speechSynthesizer.
         The AVSpeechSynthesizer object produces synthesized speech from text and
         provides methods for controlling or monitoring the progress of ongoing speech.
         */
        let speechSynthesizer = AVSpeechSynthesizer()
       
        /*
         Calling speechSynthesizer's speak method adds the speechUtterance to a queue;
         utterances are spoken in the order in which they are added to the queue.
         */
        speechSynthesizer.speak(speechUtterance)
    }
  
}
 
struct TextToSpeech_Previews: PreviewProvider {
    static var previews: some View {
        TextToSpeech()
    }
}
 
 
