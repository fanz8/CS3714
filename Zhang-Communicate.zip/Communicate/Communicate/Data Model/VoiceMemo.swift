//
//  VoiceMemo.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct VoiceMemo: Hashable, Codable, Identifiable {
    /*
     id is used also as the unique filename.m4a of the
     voice recording stored in document directory on user's device
     */
    var id: UUID
    var title: String
    var dateTime: String
    var duration: String
  
}
 
 
