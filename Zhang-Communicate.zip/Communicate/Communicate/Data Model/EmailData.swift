//
//  EmailData.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import Foundation
import SwiftUI
import MessageUI
 
struct Email: UIViewControllerRepresentable {
 
    @Binding var isShowing: Bool
 
    class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
 
        @Binding var isShowing: Bool
 
        init(isShowing: Binding<Bool>) {
            _isShowing = isShowing
        }
 
        func mailComposeController(_ controller: MFMailComposeViewController,
                                   didFinishWith result: MFMailComposeResult,
                                   error: Error?) {
            isShowing = false
        }
    }
 
    func makeCoordinator() -> Coordinator {
        return Coordinator(isShowing: $isShowing)
    }
 
    func makeUIViewController(context: UIViewControllerRepresentableContext<Email>) -> MFMailComposeViewController {
       
        // Specify sample values that can be changed by the user
        let subjectLine     = "Enter subject here"
        let emailContent    = "Please provide your feedback to Apple"
        let emailTo         = ["feedback@apple.com"]
       
        /*
        MFMailComposeViewController class provides a standard interface to manage
        composing and sending an email message. Create an MFMailComposeViewController
        object and store its object reference into local variable mailComposeViewController.
        */
        let mailComposeViewController = MFMailComposeViewController()
       
        // Dress up the mailComposeViewController object
        mailComposeViewController.mailComposeDelegate = context.coordinator
        mailComposeViewController.setSubject(subjectLine)
        mailComposeViewController.setMessageBody(emailContent, isHTML: true)
        mailComposeViewController.setToRecipients(emailTo)
       
        return mailComposeViewController
    }
 
    func updateUIViewController(_ uiViewController: MFMailComposeViewController,
                                context: UIViewControllerRepresentableContext<Email>) {
        // Take no action
    }
}
 
 
 
