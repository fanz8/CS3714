//
//  VoiceMemoData.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import Foundation
import SwiftUI
import AVFoundation
 
/*
 Create an empty mutable array of VoiceMemo structs using initializer () and
 store its object reference into the global variable voiceMemoStructList.
 */
var voiceMemoStructList = [VoiceMemo]()
 
// Set document directory URL as a global constant. It is used in
// this file, RecordVoiceMemo.swift, and VoiceMemoDetail.swift
let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
 
// Global Variables
var audioSession:   AVAudioSession!
var audioRecorder:  AVAudioRecorder!
 
/*
******************************************
MARK: - Get Permission for Voice Recording
******************************************
*/
public func getPermissionForVoiceRecording() {
   
    // Create the shared audio session instance
    audioSession = AVAudioSession.sharedInstance()
   
    do {
        // Set audio session category to record and play back audio
        try audioSession.setCategory(.playAndRecord, mode: .default)
       
        // Activate the audio session
        try audioSession.setActive(true)
       
        // Request permission to record user's voice
        audioSession.requestRecordPermission() { allowed in
            DispatchQueue.main.async {
                if allowed {
                    // Permission is recorded in the Settings app on user's device
                } else {
                    // Permission is recorded in the Settings app on user's device
                }
            }
        }
    } catch {
        print("Setting category or getting permission failed!")
    }
}
 
/*
 *********************************
 MARK: - Read Voice Memo Data File
 *********************************
 */
public func readVoiceMemoDataFile() {
  
    let voiceMemoDataFilename = "VoiceMemoData.json"
  
    // Obtain URL of the voice memo data file in document directory on user's device
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(voiceMemoDataFilename)
 
    do {
        _ = try Data(contentsOf: urlOfJsonFileInDocumentDirectory)
        // Voice memo data file exists in the document directory
        voiceMemoStructList = loadFromDocumentDirectory(voiceMemoDataFilename)
    } catch {
        // Voice memo data file does not exist in the document directory.
        // This happens when there is no recorded voice memo. Take no action.
    }
}
 
/*
*********************************************************
MARK: - Load Voice Memo Data File from Document Directory
*********************************************************
*/
func loadFromDocumentDirectory<T: Decodable>(_ filename: String, as type: T.Type = T.self) -> T {
    let data: Data
  
    // Obtain URL of the JSON file in document directory on user's device
    let urlOfJsonFileInDocumentDirectory: URL? = documentDirectory.appendingPathComponent(filename)
  
    guard let file = urlOfJsonFileInDocumentDirectory
        else {
            fatalError("Unable to find \(filename) in document directory.")
        }
  
    do {
        data = try Data(contentsOf: file)
    } catch {
        fatalError("Unable to load \(filename) from document directory:\n\(error)")
    }
  
    do {
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Unable to parse \(filename) as \(T.self):\n\(error)")
    }
}
 
/*
 ********************************************************
 MARK: - Write Voice Memo Data File to Document Directory
 ********************************************************
 */
public func writeVoiceMemoDataFile() {
 
    // Obtain URL of the file in document directory on user's device
    // into which voice memo data will be written
    let urlOfJsonFileInDocumentDirectory: URL? = documentDirectory.appendingPathComponent("VoiceMemoData.json")
 
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(voiceMemoStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory!)
        } catch {
            fatalError("Unable to write encoded voice memo data to document directory!")
        }
    } else {
        fatalError("Unable to encode voice memo data!")
    }
}
 
 
 
