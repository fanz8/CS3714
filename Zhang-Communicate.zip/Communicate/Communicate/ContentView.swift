//
//  ContentView.swift
//  Communicate
//
//  Created by Osman Balci on 3/9/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct ContentView: View {
 
    var body: some View {
        TabView {
            VoiceMemos()
                .tabItem {
                    Image("TabBarIcon-VoiceMemos")
                    Text("Voice Memos")
                }
            SpeechToText()
                .tabItem {
                    Image("TabBarIcon-SpeechToText")
                    Text("Speech to Text")
                }
            TextToSpeech()
                .tabItem {
                    Image("TabBarIcon-TextToSpeech")
                    Text("Text to Speech")
                }
            SendEmail()
                .tabItem {
                    Image("TabBarIcon-SendEmail")
                    Text("Send Email")
                }
           
        }   // End of TabView
        .font(.headline)
    }
}
 
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
 
 
