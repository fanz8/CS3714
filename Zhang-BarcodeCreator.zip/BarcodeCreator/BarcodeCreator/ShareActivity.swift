//
//  ShareActivity.swift
//  BarcodeCreator
//
//  Created by ZhangFan on 2/19/20.
//  Copyright © 2020 Fan Zhang. All rights reserved.
//
 
import Foundation
import UIKit
import SwiftUI
 
let activityViewController = ActivityViewControllerRepresentable()
 
class ActivityViewController : UIViewController {
 
    var uiImage: UIImage!
 
    @objc func shareImage() {
        let activityViewController = UIActivityViewController(activityItems: [uiImage!], applicationActivities: nil)
        activityViewController.excludedActivityTypes =  [
            UIActivity.ActivityType.assignToContact,
            UIActivity.ActivityType.addToReadingList
        ]
        present(activityViewController, animated: true, completion: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
    }
}
 
struct ActivityViewControllerRepresentable: UIViewControllerRepresentable {
 
    let activityViewController = ActivityViewController()
 
    func makeUIViewController(context: Context) -> ActivityViewController {
        activityViewController
    }
    func updateUIViewController(_ uiViewController: ActivityViewController, context: Context) {
        // Unused
    }
    func shareImage(uiImage: UIImage) {
        activityViewController.uiImage = uiImage
        activityViewController.shareImage()
    }
}
 
